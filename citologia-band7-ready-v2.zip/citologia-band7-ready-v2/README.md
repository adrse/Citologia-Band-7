# Citologia — Amazfit Band 7

Mini Program offline para Amazfit Band 7 (Zepp OS 1.0).

Esta V2 usa a nomenclatura de target e plataformas observada em projetos funcionais da Band 7:
- target: `band-7`
- deviceSource 252: `amazfit-band7-nfc`
- deviceSource 253: `amazfit-band7`
- deviceSource 254: `amazfit-band7-w`
- designWidth: 194

Inclui um ícone em `assets/band-7/icon.png`.
