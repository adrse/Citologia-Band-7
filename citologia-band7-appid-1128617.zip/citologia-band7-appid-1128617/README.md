# Citologia — Amazfit Band 7

Mini Program offline para Amazfit Band 7 (Zepp OS 1.0).

## App ID

Este projeto já está configurado com o App ID oficial informado pelo desenvolvedor:

`1128617`

## Build

Target: `band-7`

Dispositivos:
- Amazfit Band 7 NFC — deviceSource 252
- Amazfit Band 7 — deviceSource 253
- Amazfit Band 7 W — deviceSource 254

Design width: 194 px.
