const CONTENT = [
  {
    title: 'Teoria celular',
    body: 'CONCEITO\nA célula é a unidade estrutural e funcional básica dos seres vivos.\n\nPRINCÍPIOS\n• Todo ser vivo é formado por uma ou mais células.\n• A célula é a unidade básica da vida.\n• Toda célula surge de outra célula preexistente.\n\nLEMBRE\nOrganismos podem ser unicelulares ou multicelulares.'
  },
  {
    title: 'Procarionte x eucarionte',
    body: 'PROCARIONTE\nNão possui núcleo delimitado por membrana. O DNA fica no nucleoide. Bactérias são exemplos.\n\nEUCARIONTE\nPossui núcleo verdadeiro e organelas membranosas. Animais, plantas, fungos e protozoários são eucariontes.\n\nDIFERENÇA-CHAVE\nA presença de núcleo organizado e organelas membranosas.'
  },
  {
    title: 'Membrana plasmática',
    body: 'FUNÇÃO\nSepara o meio interno do externo e controla a entrada e saída de substâncias.\n\nESTRUTURA\nÉ formada principalmente por uma bicamada de fosfolipídios com proteínas associadas.\n\nMODELO\nChamado mosaico fluido porque lipídios e proteínas têm mobilidade.\n\nIMPORTANTE\nPossui permeabilidade seletiva.'
  },
  {
    title: 'Transporte na membrana',
    body: 'PASSIVO\nNão gasta ATP. Inclui difusão simples, difusão facilitada e osmose.\n\nATIVO\nGasta energia para transportar substâncias contra o gradiente de concentração.\n\nOSMOSE\nMovimento de água através de membrana semipermeável.\n\nVESICULAR\nEndocitose leva material para dentro; exocitose leva para fora.'
  },
  {
    title: 'Citoplasma e citosol',
    body: 'CITOPLASMA\nRegião entre a membrana plasmática e o núcleo. Contém citosol, organelas e citoesqueleto.\n\nCITOSOL\nParte líquida do citoplasma, rica em água, íons, proteínas e outras moléculas.\n\nFUNÇÃO\nÉ onde ocorrem diversas reações metabólicas, incluindo etapas da glicólise.'
  },
  {
    title: 'Núcleo celular',
    body: 'FUNÇÃO\nArmazena a maior parte do DNA e coordena atividades celulares por meio da expressão gênica.\n\nENVOLTÓRIO NUCLEAR\nDupla membrana com poros que controlam trocas com o citoplasma.\n\nNUCLÉOLO\nRegião relacionada à produção de RNA ribossômico e montagem de subunidades dos ribossomos.'
  },
  {
    title: 'Ribossomos e proteínas',
    body: 'RIBOSSOMOS\nEstruturas responsáveis pela síntese de proteínas.\n\nLIVRES\nProduzem principalmente proteínas usadas no citosol.\n\nLIGADOS AO RER\nProduzem proteínas destinadas à secreção, membranas ou organelas.\n\nSÍNTESE\nO ribossomo traduz a informação do RNA mensageiro em uma sequência de aminoácidos.'
  },
  {
    title: 'Retículo endoplasmático',
    body: 'RER — RUGOSO\nPossui ribossomos aderidos. Atua na síntese e no processamento inicial de proteínas.\n\nREL — LISO\nNão possui ribossomos. Participa da síntese de lipídios, desintoxicação e armazenamento de cálcio em células específicas.\n\nRESUMO\nRER: proteínas. REL: lipídios e outras funções metabólicas.'
  },
  {
    title: 'Complexo de Golgi',
    body: 'FUNÇÃO\nModifica, organiza, empacota e direciona proteínas e lipídios recebidos principalmente do retículo endoplasmático.\n\nVESÍCULAS\nO transporte de substâncias ocorre por pequenas vesículas.\n\nIMPORTANTE\nParticipa da secreção celular e da formação de lisossomos.'
  },
  {
    title: 'Lisossomos e peroxissomos',
    body: 'LISOSSOMOS\nPossuem enzimas digestivas. Fazem digestão intracelular e reciclagem de componentes celulares.\n\nPEROXISSOMOS\nParticipam de reações de oxidação e ajudam a degradar substâncias tóxicas, incluindo peróxido de hidrogênio.\n\nDIFERENÇA\nLisossomo: digestão. Peroxissomo: oxidação e detoxificação.'
  },
  {
    title: 'Mitocôndrias',
    body: 'FUNÇÃO\nProduzem grande parte do ATP utilizado pela célula por meio da respiração celular aeróbica.\n\nESTRUTURA\nPossuem membrana externa e interna. A membrana interna forma cristas.\n\nMATRIZ\nContém enzimas, DNA mitocondrial e ribossomos próprios.\n\nLEMBRE\nSão muito numerosas em células com alta demanda energética.'
  },
  {
    title: 'Citoesqueleto',
    body: 'FUNÇÃO\nMantém a forma celular, organiza estruturas internas e participa de movimentos e transporte intracelular.\n\nCOMPONENTES\n• Microfilamentos de actina.\n• Filamentos intermediários.\n• Microtúbulos.\n\nMICROTÚBULOS\nTambém participam da formação do fuso mitótico, cílios e flagelos.'
  },
  {
    title: 'Ciclo celular e mitose',
    body: 'INTERFASE\nG1: crescimento. S: duplicação do DNA. G2: preparação para divisão.\n\nMITOSE\nOrigina duas células-filhas geneticamente semelhantes.\n\nFASES\nPrófase → metáfase → anáfase → telófase.\n\nCITOCINESE\nDivisão do citoplasma ao final do processo.'
  },
  {
    title: 'Meiose',
    body: 'FUNÇÃO\nForma células haploides e aumenta a variabilidade genética.\n\nDIVISÕES\nOcorrem duas divisões sucessivas: meiose I e meiose II.\n\nRESULTADO\nUma célula diploide pode originar quatro células haploides.\n\nIMPORTANTE\nNa prófase I pode ocorrer crossing-over entre cromossomos homólogos.'
  }
]

Page({
  topicIndex: 0,

  onInit(params) {
    try {
      const parsed = JSON.parse(params || '{}')
      const index = Number(parsed.index)
      this.topicIndex = index >= 0 && index < CONTENT.length ? index : 0
    } catch (e) {
      this.topicIndex = 0
    }
  },

  build() {
    hmUI.setStatusBarVisible(false)
    hmUI.setLayerScrolling(true)

    const item = CONTENT[this.topicIndex]

    hmUI.createWidget(hmUI.widget.TEXT, {
      x: 10,
      y: 10,
      w: 174,
      h: 52,
      color: 0x60d5ff,
      text_size: 21,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V,
      text_style: hmUI.text_style.WRAP,
      text: item.title
    })

    hmUI.createWidget(hmUI.widget.FILL_RECT, {
      x: 22,
      y: 66,
      w: 150,
      h: 2,
      color: 0x333333
    })

    const layout = hmUI.getTextLayout(item.body, {
      text_size: 17,
      text_width: 174,
      wrapped: 1
    })

    const bodyHeight = Math.max(layout.height + 30, 270)

    hmUI.createWidget(hmUI.widget.TEXT, {
      x: 10,
      y: 80,
      w: 174,
      h: bodyHeight,
      color: 0xffffff,
      text_size: 17,
      align_h: hmUI.align.LEFT,
      align_v: hmUI.align.TOP,
      text_style: hmUI.text_style.WRAP,
      line_space: 4,
      text: item.body
    })

    hmUI.createWidget(hmUI.widget.TEXT, {
      x: 10,
      y: 90 + bodyHeight,
      w: 174,
      h: 40,
      color: 0x777777,
      text_size: 14,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V,
      text_style: hmUI.text_style.NONE,
      text: 'Deslize para cima • Volte para temas'
    })
  }
})
