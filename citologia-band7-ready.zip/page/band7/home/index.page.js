const TOPICS = [
  { n: '01', name: 'Teoria celular' },
  { n: '02', name: 'Procarionte x eucarionte' },
  { n: '03', name: 'Membrana plasmática' },
  { n: '04', name: 'Transporte na membrana' },
  { n: '05', name: 'Citoplasma e citosol' },
  { n: '06', name: 'Núcleo celular' },
  { n: '07', name: 'Ribossomos e proteínas' },
  { n: '08', name: 'Retículo endoplasmático' },
  { n: '09', name: 'Complexo de Golgi' },
  { n: '10', name: 'Lisossomos e peroxissomos' },
  { n: '11', name: 'Mitocôndrias' },
  { n: '12', name: 'Citoesqueleto' },
  { n: '13', name: 'Ciclo celular e mitose' },
  { n: '14', name: 'Meiose' }
]

Page({
  build() {
    hmUI.setStatusBarVisible(false)
    hmUI.setLayerScrolling(false)

    hmUI.createWidget(hmUI.widget.TEXT, {
      x: 10,
      y: 10,
      w: 174,
      h: 34,
      color: 0x60d5ff,
      text_size: 24,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V,
      text_style: hmUI.text_style.NONE,
      text: 'CITOLOGIA'
    })

    hmUI.createWidget(hmUI.widget.TEXT, {
      x: 10,
      y: 42,
      w: 174,
      h: 22,
      color: 0xaaaaaa,
      text_size: 14,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V,
      text_style: hmUI.text_style.NONE,
      text: 'Toque em um tema'
    })

    hmUI.createWidget(hmUI.widget.SCROLL_LIST, {
      x: 10,
      y: 70,
      w: 174,
      h: 288,
      item_space: 8,
      item_config: [
        {
          type_id: 1,
          item_bg_color: 0x1d1d1f,
          item_bg_radius: 12,
          text_view: [
            {
              x: 10,
              y: 0,
              w: 28,
              h: 50,
              key: 'n',
              color: 0x60d5ff,
              text_size: 15
            },
            {
              x: 42,
              y: 0,
              w: 122,
              h: 50,
              key: 'name',
              color: 0xffffff,
              text_size: 16
            }
          ],
          text_view_count: 2,
          item_height: 50
        }
      ],
      item_config_count: 1,
      data_array: TOPICS,
      data_count: TOPICS.length,
      item_click_func: (list, index) => {
        hmApp.gotoPage({
          url: 'page/band7/detail/index.page',
          param: JSON.stringify({ index })
        })
      }
    })
  }
})
