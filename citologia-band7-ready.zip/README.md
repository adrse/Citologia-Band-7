# Citologia — Amazfit Band 7

Mini Program offline para **Amazfit Band 7 (Zepp OS 1.0)**.

## O que esta versão faz

- Menu rolável com 14 temas de Citologia.
- Toque em um tema para abrir um resumo.
- Página de leitura com rolagem vertical.
- Funciona sem internet e sem celular depois de instalado.
- Projeto configurado para os `deviceSource` 252, 253 e 254 da Amazfit Band 7.

## Estrutura

```text
citologia-band7/
├── app.js
├── app.json
├── assets/
│   └── band7/
└── page/
    └── band7/
        ├── home/
        │   ├── index.page.js
        │   └── index.page.json
        └── detail/
            ├── index.page.js
            └── index.page.json
```

## Pelo celular usando GitHub Codespaces

1. Crie um repositório no GitHub e envie estes arquivos mantendo a estrutura.
2. Abra o repositório no GitHub pelo navegador.
3. Abra um **Codespace** para o repositório.
4. No terminal do Codespace, instale o Zeus CLI:

```bash
npm i @zeppos/zeus-cli -g
```

5. Entre na pasta do projeto, se necessário, e gere a prévia para aparelho real:

```bash
zeus preview
```

6. O Zeus mostrará um QR Code.
7. No Zepp, com o modo desenvolvedor ativado, use a opção de escanear/instalar Mini Program e instale na Band 7.

## Observação sobre appId

O `app.json` desta versão usa um `appId` provisório para desenvolvimento. Se o portal/Zeus solicitar um App ID registrado na sua conta Zepp, substitua `1102401` pelo ID fornecido pela Zepp.

## Próximas melhorias planejadas

- Subtópicos dentro de cada tema.
- Favoritos.
- Quiz rápido.
- Flashcards.
- Tela “Revisão rápida”.
- Conteúdo personalizado conforme suas aulas.
