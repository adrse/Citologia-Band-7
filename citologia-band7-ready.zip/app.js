App({
  globalData: {},
  onCreate() {
    console.log('Citologia: app iniciado')
  },
  onDestroy() {
    console.log('Citologia: app encerrado')
  }
})
